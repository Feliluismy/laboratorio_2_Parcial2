﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.Text.Json;
using System.Threading.Tasks;
using System.IO;

namespace Vista
{
    public class Serializadora : IGuardar<Serie>
    {
        public void Guardar(List<Serie> lista, string ruta)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(ruta))
                {
                    XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Serie>));

                    xmlSerializer.Serialize(sw, lista);
                }
            }
            catch (ArgumentException ex)
            {
                throw new ArgumentException();
            }

        }
        private void IGuardar<List<Serie>>.Guardar(List<Serie> lista, string ruta)
        {
            try
            {
                Guardar(lista, ruta);
            }
            catch (BackLogException ex)
            {
                Logger.Log(ex.Message);    
            }
        }
    }
}
