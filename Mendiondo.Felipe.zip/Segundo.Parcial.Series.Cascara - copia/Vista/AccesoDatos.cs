﻿using Google.Protobuf.Compiler;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vista
{
    public static class AccesoDatos
    {
        static private MySqlCommand comando;
        static private MySqlConnection conexion;

        static AccesoDatos()
        {
            comando = new MySqlCommand();
            conexion = new MySqlConnection(@"Server=localhost;Database=20240701_SP;User ID=root;Password=luosmy;");
            comando.CommandType = System.Data.CommandType.Text;
            comando.Connection = conexion;
        }
        public static void ActualizarSerie(Serie item)
        {
            try
            {
                comando.Parameters.Clear();
                conexion.Open();
                comando.CommandText = $"INSERT INTO Series (alumno) VALUES (@Alumno)";
                comando.Parameters.AddWithValue("@Alumno", "Felipe Mendiondo");
                int rows = comando.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally { conexion.Close(); }
        }
        public static List<Serie> ObtenerBaklog()
        {
            List<Serie> list = new List<Serie>();
            conexion.Open();
            string query = "SELECT * FROM Series";
            using (var command = new MySqlCommand(query, conexion))
            {
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new Serie(reader["Series"].ToString(), Convert.ToString(reader["Genero"])));

                    }
                }
            }
            return list;
        }

    }
}
