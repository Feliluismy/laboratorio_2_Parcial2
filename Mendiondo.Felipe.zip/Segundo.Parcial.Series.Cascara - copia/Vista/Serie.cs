﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vista
{
    public class Serie
    {
        private string nombre;
        private string genero;

        public Serie()
        {
            this.nombre = string.Empty;
            this.genero = string.Empty;
        }
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        public string Genero
        {
            get { return genero; }
            set { genero = value; }
        }
        public Serie(string nombre, string genero)
        {
            this.nombre = nombre;
            this.genero = genero;
        }
        public override string ToString()
        {
            return $"Nombre: {Nombre} | Genero: {Genero}";
        }
    }
}
