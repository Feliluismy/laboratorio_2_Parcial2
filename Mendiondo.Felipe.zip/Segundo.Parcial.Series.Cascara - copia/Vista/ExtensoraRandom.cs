﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vista
{
    static class ExtensoraRandom
    {
        public static int GenerarRandom(this List<Serie> series)
        {
            Random rd = new Random();
            return rd.Next(0, series.Count - 1);
        }
    }
}
