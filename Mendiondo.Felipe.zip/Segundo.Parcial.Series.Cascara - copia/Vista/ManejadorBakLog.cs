﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Vista
{
    public class ManejadorBacklog
    {
        public delegate void DelegadorBaklog(Serie serie);
        NuevaSeriePAraVer(Serie serie);
        public void IniciarManejador(List<Serie> series)
        {
            Task.Factory.StartNew(() =>
            {
                MoverSeries(series);
            });
        }
        private void MoverSeries(List<Serie> series)
        {
            if (series == null)
            {
                AccesoDatos.ActualizarSerie(series[ExtensoraRandom.GenerarRandom(series)]);
                Thread.Sleep(1500);
                NuevaSeriePAraVer(Serie serie);
            }
            else
            {
                Console.WriteLine("No existen series en la lista");
            }
        }
    }
}
